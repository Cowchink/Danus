# Danus Jam & Chill — Setup 10 menit
1. **Supabase**: supabase.com > New project > SQL Editor > paste `schema.sql` > Run.
2. Project Settings > API: salin **Project URL** & **anon public key** ke `config.js`.
3. **Vercel**: taruh folder ini di GitHub (atau `npx vercel` di folder ini) > Deploy. Tidak perlu build, ini static.
4. Bagikan link ke panitia. Pertama buka, isi nama (tampil di checklist/transaksi).
Tanpa langkah 1-2 app tetap jalan, tapi data hanya di HP masing-masing (mode lokal).

Keamanan: siapa pun yang punya link bisa baca/tulis. Jangan sebar di publik; cukup grup panitia.
