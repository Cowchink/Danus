// Isi setelah bikin project Supabase (Project Settings > API). Kosong = mode lokal (data hanya di HP sendiri).
window.APP_CONFIG = {
  SUPABASE_URL: "https://sizuwvpwirhpbfpzwhpq.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNpenV3dnB3aXJocGJmcHp3aHBxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM5ODY5NzYsImV4cCI6MjEwOTU2Mjk3Nn0.HMx5nQPiEAozW-fhNyeD0VeiCQJIFem5gMH9vkYIjyU"
};