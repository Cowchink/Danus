-- Jalankan di Supabase > SQL Editor > New query > Run
create table if not exists transactions(
  id uuid primary key default gen_random_uuid(),
  date date not null, time text, kind text not null check (kind in ('in','out')),
  product text, category text, qty int default 0, amount numeric not null default 0,
  method text default 'cash', channel text, note text, by text,
  order_id text, status text default 'paid',
  created_at timestamptz default now());
-- Jika tabel transactions sudah terlanjur dibuat dari versi lama, jalankan 2 baris ini:
alter table transactions add column if not exists order_id text;
alter table transactions add column if not exists status text default 'paid';

create table if not exists checklist(
  id uuid primary key default gen_random_uuid(),
  date date not null, cat text not null, task text not null,
  done boolean default false, done_by text, done_at text, created_at timestamptz default now());
create table if not exists stock(
  id uuid primary key default gen_random_uuid(),
  date date not null, product text not null, prepared int default 0, unique(date,product));
create table if not exists schedule(
  id uuid primary key default gen_random_uuid(),
  start_time text not null, end_time text not null, label text not null, type text default 'jual');
create table if not exists settings(key text primary key, value jsonb);
create table if not exists po(
  id uuid primary key default gen_random_uuid(),
  date date not null, name text not null, product text, qty int default 1, total numeric default 0,
  place text default 'Kampus', done boolean default false, created_at timestamptz default now());

-- Akses terbuka untuk semua yang punya link (anon). Lihat catatan keamanan di README.
do $$ declare t text; begin
  foreach t in array array['transactions','checklist','stock','schedule','settings','po'] loop
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists "open_all" on %I', t);
    execute format('create policy "open_all" on %I for all to anon using (true) with check (true)', t);
    execute format('alter publication supabase_realtime add table %I', t);
  end loop; end $$;

insert into schedule(start_time,end_time,label,type) values
('07:30','09:00','Logistik pagi: ambil roti, es batu, seduh teh, masak nutrijel','siap'),
('09:00','11:30','Stand Gazebo FST buka','jual'),
('11:30','12:15','KELILING #1 (jam istirahat kelas)','jual'),
('12:15','13:00','Istirahat / sholat / makan (gantian)','istirahat'),
('13:00','15:00','Stand Gazebo lanjut','jual'),
('15:00','16:00','KELILING #2 (sore)','jual'),
('16:00','16:30','Stand tutup, hitung sisa','tutup'),
('16:30','17:30','Rekap kas, setor roti konsinyasi, retur','tutup');
